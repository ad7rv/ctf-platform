you opened the stash!
flag: CTF{z1p_z1p_h00r4y}
